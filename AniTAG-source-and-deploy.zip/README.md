# AniTAG

A personal anime discovery and watchlist frontend with an in-site episode page and HTML5/HLS player.

## Run the frontend

```bash
npm install
npm run dev
```

This starts both the Vite frontend and the local streaming API. Vite prints the site URL (normally `http://localhost:5173`); the API listens on port `4000`.

## Streaming API configuration

AniList supplies metadata only; it does not supply video files. AniTAG therefore connects to a separate streaming API that you operate or are authorized to use.

The supplied Anime API is included under `api/`. For devices opening AniTAG over the same local network, the browser uses the current site hostname on port `4000` automatically. Set `VITE_STREAM_API_BASE` in `.env` only when using a different API host, then restart Vite.

The adapter is compatible with the episode/source response shape used by the provided Anime-API reference:

- `GET /episodes/:anilistId` returns provider objects with `episodes.sub` and/or `episodes.dub` arrays. Episode items include `id`, `number`, and optionally `title`.
- Each returned episode `id` is a relative watch path, such as `watch/provider/ANILIST_ID/sub/provider-1`.
- `GET /<episode-id>` returns `{ "streams": [{ "url": "https://...", "type": "hls", "server": "...", "subtitles": [] }] }` (a `sources` array is also accepted).

Only connect content sources you are authorized to stream. Availability, audio languages, subtitles, CORS behavior, and playback quality depend on the configured API/provider. A stream URL may fail if the provider is offline or does not permit browser playback.

## Playback features

- In-site episode page, episode list and previous/next navigation.
- Japanese/sub and dub controls appear based on available episode metadata.
- Provider and stream selection when multiple choices exist.
- HLS playback via `hls.js` where native browser playback is unavailable; native video controls for play/pause, seeking and fullscreen.
- Subtitle tracks when supplied by the source API.
- Loading states, missing-source states and actionable API/player errors.

## Notes

The frontend does not bundle stream links or scrape third-party streaming websites. The backend configured through `VITE_STREAM_API_BASE` is responsible for returning lawful, playable source URLs. Browser playback also requires the source to allow cross-origin requests when applicable.
